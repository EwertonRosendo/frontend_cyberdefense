export const mockCases = [
  {
    name: "João Silva Santos",
    cpf: "123.456.789-00",
    birthDate: "1995-03-15",
    process: "CB-2024-001",
    status: "Em Análise",
    date: "15/03/2024",
    description: "Caso de cyberbullying envolvendo ameaças através de redes sociais.",
    sanctions: {
      suspension: {
        title: "Suspensão da Conta",
        description: "30 dias (até 04/05/2025)"
      },
      history: {
        title: "Registro no Histórico",
        description: "Violação registrada permanentemente"
      },
      contactRestrictions: {
        title: "Restrições de Contato",
        description: "Bloqueio permanente de interação com a vítima"
      }
    }
  },
  {
    name: "Maria Oliveira Costa",
    cpf: "987.654.321-00",
    birthDate: "1998-07-22",
    process: "CB-2024-002",
    status: "Confirmado",
    date: "12/03/2024",
    description: "Disseminação de conteúdo ofensivo e difamatório.",
    sanctions: {
      suspension: {
        title: "Suspensão da Conta",
        description: "60 dias (até 11/05/2025)"
      },
      history: {
        title: "Registro no Histórico",
        description: "Violação grave registrada permanentemente"
      },
      contactRestrictions: {
        title: "Restrições de Contato",
        description: "Bloqueio total de comunicação digital"
      }
    }
  },
  {
    name: "Pedro Henrique Lima",
    cpf: "456.789.123-00",
    birthDate: "1997-11-08",
    process: "CB-2024-003",
    status: "Arquivado",
    date: "10/03/2024",
    description: "Caso arquivado após esclarecimentos e acordo entre as partes.",
    sanctions: {
      suspension: {
        title: "Advertência Formal",
        description: "Orientação sobre uso responsável"
      },
      history: {
        title: "Registro Temporário",
        description: "Registro removido após 6 meses"
      },
      contactRestrictions: {
        title: "Monitoramento",
        description: "Acompanhamento por 30 dias"
      }
    }
  }
];
