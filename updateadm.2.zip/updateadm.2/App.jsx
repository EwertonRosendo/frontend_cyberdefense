import React, { useState, useEffect } from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './Header';
import WelcomeSection from './WelcomeSection';
import CaseForm from './CaseForm';
import CaseTable from './CaseTable';
import Footer from './Footer';
import { mockCases } from './mockData';

function App() {
  const [theme, setTheme] = useState('light');
  const [cases, setCases] = useState(mockCases);
  const [editingCase, setEditingCase] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);

  useEffect(() => {
    const savedTheme = localStorage.getItem('darkMode') === 'true' ? 'dark' : 'light';
    setTheme(savedTheme);
    document.documentElement.setAttribute('data-theme', savedTheme);
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('darkMode', newTheme === 'dark');
  };

  const handleAddCase = (newCase) => {
    const caseWithDate = {
      ...newCase,
      date: new Date().toLocaleDateString('pt-BR')
    };
    setCases([caseWithDate, ...cases]);
    setCurrentPage(1);
  };

  const handleEditCase = (updatedCase, index) => {
    const updatedCases = [...cases];
    updatedCases[index] = { ...updatedCase, date: cases[index].date };
    setCases(updatedCases);
    setEditingCase(null);
  };

  const handleDeleteCase = (index) => {
    const updatedCases = cases.filter((_, i) => i !== index);
    setCases(updatedCases);
    if (editingCase && editingCase.index === index) {
      setEditingCase(null);
    }
  };

  const startEditing = (caseData, index) => {
    setEditingCase({ ...caseData, index });
  };

  const cancelEditing = () => {
    setEditingCase(null);
  };

  return (
    <div className="h-full text-base-content">
      <Header theme={theme} onToggleTheme={toggleTheme} />
      <Routes>
        <Route path="/" element={<WelcomeSection />} />
        <Route 
          path="/cases" 
          element={
            <CaseTable 
              cases={cases} 
              currentPage={currentPage} 
              onPageChange={setCurrentPage} 
              onEditCase={startEditing} 
              onDeleteCase={handleDeleteCase} 
            />
          } 
        />
        <Route 
          path="/add-case" 
          element={
            <CaseForm 
              editingCase={editingCase} 
              onAddCase={handleAddCase} 
              onEditCase={handleEditCase} 
              onCancelEditing={cancelEditing} 
            />
          } 
        />
      </Routes>
      <Footer />
    </div>
  );
}

export default App;
