import React, { useState, useEffect } from 'react';
import SanctionsSection from './SanctionsSection';

const CaseForm = ({ editingCase, onAddCase, onEditCase, onCancelEditing }) => {
  const [formData, setFormData] = useState({
    name: '',
    cpf: '',
    birthDate: '',
    process: '',
    status: 'Em Análise',
    description: '',
    sanctions: {
      suspension: {
        title: 'Suspensão da Conta',
        description: '30 dias (até 04/05/2025)'
      },
      history: {
        title: 'Registro no Histórico',
        description: 'Violação registrada permanentemente'
      },
      contactRestrictions: {
        title: 'Restrições de Contato',
        description: 'Bloqueio permanente de interação com a vítima'
      }
    }
  });
  const [errors, setErrors] = useState({});
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    if (editingCase) {
      setFormData({
        name: editingCase.name || '',
        cpf: editingCase.cpf || '',
        birthDate: editingCase.birthDate || '',
        process: editingCase.process || '',
        status: editingCase.status || 'Em Análise',
        description: editingCase.description || '',
        sanctions: editingCase.sanctions || formData.sanctions
      });
    }
  }, [editingCase]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const handleSanctionChange = (sanctionType, field, value) => {
    setFormData(prev => ({
      ...prev,
      sanctions: {
        ...prev.sanctions,
        [sanctionType]: {
          ...prev.sanctions[sanctionType],
          [field]: value
        }
      }
    }));
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.name.trim()) newErrors.name = 'Nome Completo do Acusado é obrigatório.';
    if (!formData.cpf.trim()) newErrors.cpf = 'CPF é obrigatório.';
    if (!formData.process.trim()) newErrors.process = 'Número do Processo é obrigatório.';
    if (!formData.status) newErrors.status = 'Status é obrigatório.';
    if (!formData.birthDate) newErrors.birthDate = 'Data de Nascimento é obrigatória.';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    if (editingCase) {
      onEditCase(formData, editingCase.index);
      setSuccessMessage('Caso atualizado com sucesso!');
    } else {
      onAddCase(formData);
      setSuccessMessage('Novo caso cadastrado com sucesso!');
    }

    handleReset();
    
    // Clear success message after 3 seconds
    setTimeout(() => setSuccessMessage(''), 3000);
  };

  const handleReset = () => {
    setFormData({
      name: '',
      cpf: '',
      birthDate: '',
      process: '',
      status: 'Em Análise',
      description: '',
      sanctions: {
        suspension: {
          title: 'Suspensão da Conta',
          description: '30 dias (até 04/05/2025)'
        },
        history: {
          title: 'Registro no Histórico',
          description: 'Violação registrada permanentemente'
        },
        contactRestrictions: {
          title: 'Restrições de Contato',
          description: 'Bloqueio permanente de interação com a vítima'
        }
      }
    });
    setErrors({});
    if (editingCase) {
      onCancelEditing();
    }
  };

  return (
    <section className="bg-white rounded-lg shadow mb-8">
      <div className="p-6">
        {successMessage && (
          <div className="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4">
            <div className="flex">
              <div className="py-1">
                <i className="fa-solid fa-check-circle"></i>
              </div>
              <div className="ml-3">
                <p className="text-sm">{successMessage}</p>
              </div>
            </div>
          </div>
        )}

        {editingCase && (
          <div className="editing-mode-indicator mb-4" style={{ display: 'block' }}>
            <div className="flex justify-between items-center">
              <div>
                <span className="font-medium">Modo de Edição</span>
                <p className="text-sm text-gray-600">Você está editando um caso existente.</p>
              </div>
              <button 
                type="button" 
                onClick={onCancelEditing}
                className="text-blue-600 hover:text-blue-800 text-sm"
              >
                Cancelar Edição
              </button>
            </div>
          </div>
        )}
        
        <h2 className="text-xl font-semibold mb-6">
          {editingCase ? 'Editar Caso' : 'Cadastrar Novo Caso'}
        </h2>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nome Completo do Acusado
              </label>
              <input 
                className="w-full border rounded-lg px-4 py-2" 
                type="text" 
                name="name"
                value={formData.name}
                onChange={handleInputChange}
              />
              {errors.name && <p className="text-red-600 text-sm mt-1">{errors.name}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">CPF</label>
              <input 
                className="w-full border rounded-lg px-4 py-2" 
                type="text" 
                name="cpf"
                value={formData.cpf}
                onChange={handleInputChange}
              />
              {errors.cpf && <p className="text-red-600 text-sm mt-1">{errors.cpf}</p>}
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Data de Nascimento
              </label>
              <input 
                className="w-full border rounded-lg px-4 py-2" 
                type="date" 
                name="birthDate"
                value={formData.birthDate}
                onChange={handleInputChange}
              />
              {errors.birthDate && <p className="text-red-600 text-sm mt-1">{errors.birthDate}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Número do Processo</label>
              <input 
                className="w-full border rounded-lg px-4 py-2" 
                type="text" 
                name="process"
                value={formData.process}
                onChange={handleInputChange}
              />
              {errors.process && <p className="text-red-600 text-sm mt-1">{errors.process}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
              <select 
                className="w-full border rounded-lg px-4 py-2" 
                name="status"
                value={formData.status}
                onChange={handleInputChange}
              >
                <option value="Em Análise">Em Análise</option>
                <option value="Confirmado">Confirmado</option>
                <option value="Arquivado">Arquivado</option>
              </select>
              {errors.status && <p className="text-red-600 text-sm mt-1">{errors.status}</p>}
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Descrição do Caso
            </label>
            <textarea 
              className="w-full border rounded-lg px-4 py-2" 
              rows="4" 
              name="description"
              value={formData.description}
              onChange={handleInputChange}
            />
          </div>

          <SanctionsSection 
            sanctions={formData.sanctions}
            onSanctionChange={handleSanctionChange}
          />

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Evidências</label>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
              <i className="fa-solid fa-cloud-upload text-3xl text-gray-400 mb-2"></i>
              <p className="text-sm text-gray-500">Arraste arquivos ou clique para fazer upload</p>
              <input className="hidden" type="file" multiple />
              <button 
                className="mt-2 text-blue-600 hover:text-blue-800 text-sm" 
                type="button"
              >
                Selecionar Arquivos
              </button>
            </div>
          </div>
          
          <div className="flex justify-end space-x-4">
            <button 
              className="px-6 py-2 border rounded-lg hover:bg-gray-50" 
              type="button"
              onClick={handleReset}
            >
              Cancelar
            </button>
            <button 
              className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700" 
              type="submit"
            >
              {editingCase ? 'Salvar Alterações' : 'Cadastrar Caso'}
            </button>
          </div>
        </form>
      </div>
    </section>
  );
};

export default CaseForm;
