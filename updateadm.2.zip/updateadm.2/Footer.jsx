import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-white border-t mt-12">
      <div className="container mx-auto px-6 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="font-semibold text-gray-800 mb-4">CyberDefense</h3>
            <p className="text-gray-600 text-sm">
              Sistema de Administração e Fiscalização de Casos de Cyberbullying
            </p>
          </div>
          <div>
            <h4 className="font-medium text-gray-800 mb-4">Recursos</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><a href="#" className="hover:text-blue-600">Documentação</a></li>
              <li><a href="#" className="hover:text-blue-600">Suporte</a></li>
              <li><a href="#" className="hover:text-blue-600">FAQ</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium text-gray-800 mb-4">Legal</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><a href="#" className="hover:text-blue-600">Termos de Uso</a></li>
              <li><a href="#" className="hover:text-blue-600">Política de Privacidade</a></li>
              <li><a href="#" className="hover:text-blue-600">Cookies</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium text-gray-800 mb-4">Contato</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>Email: suporte@cyberdefense.gov.br</li>
              <li>Telefone: (11) 1234-5678</li>
              <li>Horário: 8h às 18h</li>
            </ul>
          </div>
        </div>
        <div className="border-t pt-8 mt-8 text-center text-sm text-gray-600">
          <p>&copy; 2024 CyberDefense. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
