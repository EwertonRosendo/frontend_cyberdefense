import React from 'react';

const SanctionsSection = ({ sanctions, onSanctionChange }) => {
  const sanctionTypes = [
    {
      key: 'suspension',
      icon: 'fa-solid fa-ban',
      iconColor: 'text-red-500',
      data: sanctions.suspension
    },
    {
      key: 'history',
      icon: 'fa-solid fa-history',
      iconColor: 'text-yellow-500',
      data: sanctions.history
    },
    {
      key: 'contactRestrictions',
      icon: 'fa-solid fa-user-slash',
      iconColor: 'text-blue-500',
      data: sanctions.contactRestrictions
    }
  ];

  return (
    <div className="space-y-6">
      <div className="info-card">
        <h2 className="text-xl font-semibold mb-4">Quais Serão as Sanções Aplicadas?</h2>
        <div className="space-y-4">
          {sanctionTypes.map(({ key, icon, iconColor, data }) => (
            <div key={key} className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <div className="flex items-center mb-2">
                <i className={`${icon} ${iconColor} mr-3`}></i>
                <input 
                  type="text" 
                  className="font-medium border rounded-lg px-2 py-1 w-full" 
                  value={data.title}
                  onChange={(e) => onSanctionChange(key, 'title', e.target.value)}
                />
              </div>
              <textarea 
                className="text-gray-600 dark:text-gray-400 w-full border rounded-lg px-4 py-2"
                value={data.description}
                onChange={(e) => onSanctionChange(key, 'description', e.target.value)}
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SanctionsSection;
