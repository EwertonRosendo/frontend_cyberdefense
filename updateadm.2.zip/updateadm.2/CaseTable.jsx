import React from 'react';
import Pagination from './Pagination';

const CaseTable = ({ cases, currentPage, onPageChange, onEditCase, onDeleteCase }) => {
  const itemsPerPage = 3;
  const totalPages = Math.ceil(cases.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = Math.min(startIndex + itemsPerPage, cases.length);
  const currentCases = cases.slice(startIndex, endIndex);

  const getStatusClass = (status) => {
    switch (status) {
      case 'Em Análise':
        return 'bg-yellow-100 text-yellow-800';
      case 'Confirmado':
        return 'bg-green-100 text-green-800';
      case 'Arquivado':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <section className="bg-white rounded-lg shadow">
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold">Casos Cadastrados Recentemente</h2>
          <div className="flex space-x-2">
            <button className="px-4 py-2 text-sm border rounded-lg hover:bg-gray-50">
              <i className="fa-solid fa-filter mr-2"></i>Filtrar
            </button>
            <button className="px-4 py-2 text-sm border rounded-lg hover:bg-gray-50">
              <i className="fa-solid fa-download mr-2"></i>Exportar
            </button>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50">
                <th className="px-4 py-3 text-left">Nome</th>
                <th className="px-4 py-3 text-left">CPF</th>
                <th className="px-4 py-3 text-left">Processo</th>
                <th className="px-4 py-3 text-left">Status</th>
                <th className="px-4 py-3 text-left">Data</th>
                <th className="px-4 py-3 text-left">Ações</th>
              </tr>
            </thead>
            <tbody>
              {currentCases.map((caseItem, index) => (
                <tr key={startIndex + index} className="border-t">
                  <td className="px-4 py-3">{caseItem.name}</td>
                  <td className="px-4 py-3">{caseItem.cpf}</td>
                  <td className="px-4 py-3">{caseItem.process}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 rounded-full text-xs ${getStatusClass(caseItem.status)}`}>
                      {caseItem.status}
                    </span>
                  </td>
                  <td className="px-4 py-3">{caseItem.date}</td>
                  <td className="px-4 py-3">
                    <div className="flex space-x-2">
                      <button 
                        className="text-blue-600 hover:text-blue-800"
                        onClick={() => onEditCase(caseItem, startIndex + index)}
                      >
                        <i className="fa-solid fa-edit"></i>
                      </button>
                      <button 
                        className="text-red-600 hover:text-red-800"
                        onClick={() => onDeleteCase(startIndex + index)}
                      >
                        <i className="fa-solid fa-trash"></i>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {totalPages > 1 && (
          <Pagination 
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={onPageChange}
          />
        )}
      </div>
    </section>
  );
};

export default CaseTable;
