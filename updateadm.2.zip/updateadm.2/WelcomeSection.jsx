import React from 'react';

const WelcomeSection = () => {
  return (
    <section className="bg-blue-50 text-blue-800 py-6 border-b border-blue-100">
      <div className="container mx-auto px-6">
        <h2 className="text-2xl font-semibold mb-2">Bem-vindo, ADM</h2>
        <p className="text-blue-700">
          Aqui você pode registrar novos alunos à lista de acusados para que eles possam 
          responder ao caso de que foram acusados e tenham a chance de contar seu lado da história.
        </p>
      </div>
    </section>
  );
};

export default WelcomeSection;
